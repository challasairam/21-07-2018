package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.miniproject.bean.BookingDetailsBean;
import com.cg.miniproject.bean.HotelBean;
import com.cg.miniproject.bean.RoomDetailsBean;
import com.cg.miniproject.bean.UserBean;
import com.cg.miniproject.dao.IHotelBookingDao;
@Service
public class HotelBookingServiceImpl implements IHotelBookingService {

	@Autowired 
	IHotelBookingDao dao;
	public boolean register(UserBean user)  {
		return dao.register(user);
	}

	public UserBean login(UserBean user)  {
		return dao.login(user);

	}

	@Override
	public boolean addHotels(HotelBean hotel)  {


		return dao.addHotels(hotel);
	}

	@Override
	public boolean deleteHotel(Integer id)  {
		return dao.deleteHotel(id);

	}

	@Override
	public boolean addRooms(RoomDetailsBean roomDetails)  {

		return dao.addRooms(roomDetails);
	}

	@Override
	public boolean deleteRooms(Integer id){

		return dao.deleteRooms(id);
	}

	@Override
	public ArrayList<BookingDetailsBean> retrieveBookings(Integer hotelId)
			 {

		return dao.retrieveBookings(hotelId);
	}

	@Override
	public ArrayList<BookingDetailsBean> retrieveBookings(LocalDate date)
			 {

		return dao.retrieveBookings(date);
	}

	public ArrayList<HotelBean> getHotelList() {
		return dao.getHotelList();
	}

	public ArrayList<RoomDetailsBean> getRoomDetails(Integer id)
			 {
		return dao.getRoomDetails(id);
	}

	@Override
	public BookingDetailsBean insertBookingDetails(BookingDetailsBean bookingDetails)
			 {
		return dao.insertBookingDetails(bookingDetails);
	}

	@Override
	public boolean fetchUserName(String userName)  {

		return dao.fetchUserName(userName);
	}


	@Override
	public BookingDetailsBean retrieveGuestList(Integer hotelId)
			 {
		return dao.retrieveGuestList(hotelId);
	}

	public boolean viewBookingStatus(Integer userId)  {
		return dao.viewBookingStatus(userId);
	}

	@Override
	public boolean modifyHotel(HotelBean hotel) {
		return dao.modifyHotel(hotel);
	}

	@Override
	public boolean modifyRoom(RoomDetailsBean details) {
		return dao.modifyRoom(details);
	}

	@Override
	public boolean validateHotelId(Integer hotelId)  {
		return dao.validateHotelId(hotelId);
	}

	@Override
	public ArrayList<HotelBean> getHotelList(Integer hotelId) {
		return dao.getHotelList(hotelId);
	}
	@Override
	public ArrayList<RoomDetailsBean> getRoomList(RoomDetailsBean roomDetails){
		return dao.getRoomList(roomDetails);
		
	}

	@Override
	public boolean checkRoomId(Integer roomId) {
		// TODO Auto-generated method stub
		return dao.checkRoomId(roomId);
	}
}