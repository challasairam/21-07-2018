package com.cg.miniproject.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ServiceValidation {

	public int validateMobNo(String mobNo) {
		Pattern pattern = Pattern.compile("^[9876][0-9]{9}$");
		Matcher matcher = pattern.matcher(mobNo);
		int result = 1;
		if (!matcher.find()) {
			System.err.println("Mobile Number should be of 10 digits only");
			result = 0;
		}
		return result;
	}

	public int validatePhone(String phone) {
		Pattern pattern = Pattern.compile("^[9876][0-9]{9}$");
		Matcher matcher = pattern.matcher(phone);
		int result = 1;
		if (!matcher.find()) {
			System.err.println("Phone Number should be of 10 digits only");
			result = 0;
		}
		return result;
	}

	public int validateEmail(String email) {

		Pattern pattern = Pattern
				.compile("^[A-Za-z0-9]+[@]+[a-z]+[.]+[a-z]{1,4}");
		Matcher matcher = pattern.matcher(email);
		int result = 1;
		if(email.length()>15)
		{
			System.err.println("Email id should not be more than 15 characters");
			result = 0;
		}
		else if (!matcher.find()) {
			System.err.println("Enter a valid email id.");
			result = 0;
		}
		return result;

	}

	public boolean validateHotelId(String id) {
		boolean res = false;
		Pattern pattern = Pattern.compile("^[1-9][0-9]{3}$");
		Matcher matcher = pattern.matcher(id);
		if (matcher.find()) {
			res = true;
		} else {
			System.err.println("Please enter valid 4-digit hotel id");
		}
		return res;
	}

	public boolean validateRoomId(String id) {
		boolean res = false;
		Pattern pattern = Pattern.compile("^[1-9][0-9]{3}$");
		Matcher matcher = pattern.matcher(id);
		if (matcher.find()) {
			res = true;
		} else {
			System.err.println("Please enter valid 4-digit room id");
		}
		return res;
	}

	public boolean getRoomType(String name) {
		boolean res = false;
		String[] arr = { "Standard non A/C room", "Standard A/C room",
				"Exceutive A/C room", "Deluxe A/C room" };
		if (name.equals(arr[0]) || name.equals(arr[1]) || name.equals(arr[2])
				|| name.equals(arr[3]))
			res = true;
		else
			System.err
					.println("Room type should be in Standard non A/C room,Standard A/C room,Exceutive A/C room,Deluxe A/C room");
		return res;
	}

	public boolean validatePassword(String password)
	{
		
		boolean res = false;
		Pattern pattern = Pattern.compile("^[A-Za-z]{1,7}$");
		Matcher matcher = pattern.matcher(password);
		if (matcher.find()) {
			res = true;
		} else {
			System.err.println("Password should be of maximum 7 characters(does not include digits)");
		}
		return res;
		
	}
	
	public boolean validateAddress(String address)
	{
		
		boolean res = false;
		Pattern pattern = Pattern.compile("^[A-Za-z0-9/-]{1,25}$");
		Matcher matcher = pattern.matcher(address);
		if (matcher.find()) {
			res = true;
		} else {
			System.err.println("Length of address cannot be more than 25");
		}
		return res;
		
	}

	public boolean validateChoice(String choice) {
		boolean res = false;
		Pattern pattern = Pattern.compile("^[0-9]$");
		Matcher matcher = pattern.matcher(choice);
		if (matcher.find()) {
			res = true;
		} else {
			System.err.println("Selected option cannot be string or character");
		}
		return res;
	}
}
