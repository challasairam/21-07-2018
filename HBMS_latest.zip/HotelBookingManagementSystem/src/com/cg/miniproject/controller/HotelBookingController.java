package com.cg.miniproject.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.jboss.resteasy.spi.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.miniproject.bean.BookingDetailsBean;
import com.cg.miniproject.bean.HotelBean;
import com.cg.miniproject.bean.RoomDetailsBean;
import com.cg.miniproject.bean.UserBean;
import com.cg.miniproject.service.IHotelBookingService;

@Controller
public class HotelBookingController {
	@Autowired
	IHotelBookingService service;

	@RequestMapping("index")
	public ModelAndView getHomePage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("home");
		return view;
	}

	@RequestMapping("login")
	public ModelAndView getLoginPage() {
		ModelAndView view = new ModelAndView("login", "user1", new UserBean());
	
		return view;
	}

	@RequestMapping("register")
	public ModelAndView getRegisterPage() {
		ModelAndView view = new ModelAndView("register", "user", new UserBean());
		
		return view;
	}

	@RequestMapping(value = "registerDetails", method = RequestMethod.POST)
	public ModelAndView storeDetails(@ModelAttribute("user") @Valid UserBean user,
			BindingResult result,Errors errors) {
		ModelAndView view = new ModelAndView();
		if (result.hasErrors() || service.fetchUserName(user.getUserName())) {
			view = new ModelAndView("register", "user", user);
			errors.rejectValue("userName",null,"User name already exists");
			
		} else {
			
				boolean res = service.register(user);
				if (res) {
					System.out.println("success");
				} else {
					System.out.println("failure");
				}
			
			view.setViewName("home");

		}
		return view;

	}

	@RequestMapping(value = "fetchLoginDetails", method = RequestMethod.POST)
	public ModelAndView getDetails(@ModelAttribute("user1") @Valid UserBean user,
			BindingResult result, HttpServletRequest request) {
		HttpSession session = request.getSession();
		ModelAndView view = new ModelAndView();

		System.out.println("Login Page");
		if (result.hasErrors()) {
			view = new ModelAndView("login", "user1", user);
			view.addObject("message", "Login Failed");

		} else {
			
				if (user.getUserName().equals("admin"))
					user.setRole("Admin");
				else
					user.setRole("User");
				UserBean user1 = service.login(user);

				if (null != user1) {
					session.setAttribute("username", user1.getUserName());
					session.setAttribute("userid", user1.getUserId());
					if (user.getRole().equals("Admin")) {
						view = new ModelAndView("DisplayForAdmin", "hotel",
								new HotelBean());
					} else {

						ArrayList<HotelBean> hotels = service.getHotelList();

						if (!hotels.isEmpty()) {
							view = new ModelAndView("DisplayForUser", "room",
									new RoomDetailsBean());
							view.addObject("hotelList", hotels);

						} else {
							String msg = "No hotels are available for Booking!";
							view.addObject("msg", msg);
							view = new ModelAndView("DisplayForUser", "room",
									new RoomDetailsBean());
						}

					}
				} else {
					view = new ModelAndView("login", "user1", user);
					view.addObject("message", "Login Failed");
				}


		}
		return view;

	}

	@RequestMapping("getRoomDetails")
	public ModelAndView getRoomDetails(
			@ModelAttribute("room") RoomDetailsBean details) {
		ModelAndView view = new ModelAndView();
		
			ArrayList<HotelBean> hotels = service.getHotelList();
			if (!hotels.isEmpty()) {

				boolean res = service.validateHotelId(details.getHotelId());
				if (res) {
					ArrayList<RoomDetailsBean> list = service
							.getRoomDetails(details.getHotelId());
					System.out.println(list);
					if (!list.isEmpty()) {
						view = new ModelAndView("BookARoom", "room",
								new RoomDetailsBean());
						view.addObject("roomDetails", list);
						view.addObject("hotelList", hotels);
					} else {
						view = new ModelAndView("BookARoom", "room",
								new RoomDetailsBean());
						String msg = "No rooms are available in this hotel for Booking!";
						view.addObject("errorMessage", msg);
						view.addObject("hotelList", hotels);
					}
				} else {
					view = new ModelAndView("BookARoom", "room",
							new RoomDetailsBean());
					String msg = "No hotel exists with such hotel id!";
					view.addObject("errorMessage", msg);
					view.addObject("hotelList", hotels);
				}
			} else {
				view = new ModelAndView("BookARoom", "room",
						new RoomDetailsBean());
				String msg = "No hotels are available for Booking!";
				view.addObject("msg", msg);

			}
	
		return view;

	}
	@RequestMapping("BookRoom")
	public ModelAndView bookARoom(@ModelAttribute("room") RoomDetailsBean details) {

		BookingDetailsBean bookingDetails = new BookingDetailsBean();
		ModelAndView view = new ModelAndView("BookRoom", "book", bookingDetails);
		view.addObject("roomId", details.getRoomId());
		System.out.println(details.getRoomId());
		return view;
	}

	@RequestMapping("insertBooking")
	public ModelAndView insertBookingDetails(
			@ModelAttribute("book") @Valid BookingDetailsBean bookingDetails,
			BindingResult result, HttpServletRequest request,Errors errors) {
		ModelAndView view = new ModelAndView();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fdate=LocalDate.parse(bookingDetails.getBookedFromDate(),formatter);
		LocalDate tdate=LocalDate.parse(bookingDetails.getBookedToDate(),formatter);
		LocalDate cdate=LocalDate.now();
		 if(!((fdate.isAfter(cdate) || fdate.isEqual(cdate)) && (tdate.isAfter(cdate) || tdate.isEqual(cdate)) && ((fdate.isBefore(tdate) || (fdate.isEqual(tdate)))))){
			 errors.rejectValue("bookedFromDate",null,"starting date must be greater than current date and less than ending date");
			 view = new ModelAndView("BookRoom", "book", bookingDetails);
				view.addObject("roomId", bookingDetails.getRoomId());
		 }
		 else if (result.hasErrors()) {
			view = new ModelAndView("BookRoom", "book", bookingDetails);
			view.addObject("roomId", bookingDetails.getRoomId());
		} 
		 else {
			HttpSession session = request.getSession(false);
			Object s = session.getAttribute("userid");
			bookingDetails.setUserId(Integer.parseInt(s.toString()));
			
				BookingDetailsBean bookingDetails2 = service
						.insertBookingDetails(bookingDetails);
				view.addObject("id", bookingDetails2.getBookingId());
				view = new ModelAndView("DisplayForUser", "room",
						new RoomDetailsBean());
			
		}
		return view;
	}

	@RequestMapping("checkStatus")
	public ModelAndView viewBookingStatus(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView view = new ModelAndView();
		BookingDetailsBean details = new BookingDetailsBean();
		Object s = session.getAttribute("userid");
		details.setUserId(Integer.parseInt(s.toString()));
		
			ArrayList<HotelBean> hotels = service.getHotelList();
			if (!hotels.isEmpty()) {
				boolean r = service.viewBookingStatus(details.getUserId());
				System.out.println(r);
				if (r) {
					view = new ModelAndView("CheckStatus", "room",
							new RoomDetailsBean());
					String statusmsg1 = "You have already booked!";
					view.addObject("statusmsg1", statusmsg1);
					view.addObject("hotelList", hotels);
				} else {
					view = new ModelAndView("CheckStatus", "room",
							new RoomDetailsBean());
					String statusmsg2 = "Not yet booked!";
					view.addObject("statusmsg2", statusmsg2);
					view.addObject("hotelList", hotels);
				}
			} else {
				view = new ModelAndView("DisplayForUser", "room",
						new RoomDetailsBean());
				String msg = "No hotels are available for Booking!";
				view.addObject("msg", msg);
			}
	
		return view;
	}

	@RequestMapping("AddHotel")
	public ModelAndView getAddHotelPage() {
		ModelAndView view = new ModelAndView("AddHotel", "hotel", new HotelBean());
		ArrayList<String> cities=new ArrayList<>();
		cities.add("Chennai");
		cities.add("Hyderabad");
		cities.add("Bangalore");
		cities.add("Mumbai");
		cities.add("Delhi");
		cities.add("Kolkata");
		view.addObject("cities", cities);
		return view;

	}

	@RequestMapping("addHotelDetails")
	public ModelAndView saveHotelDetails(
			@ModelAttribute("hotel") @Valid HotelBean hotel, BindingResult result) {

		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("AddHotel", "hotel", hotel);
			ArrayList<String> cities=new ArrayList<>();
			cities.add("Chennai");
			cities.add("Hyderabad");
			cities.add("Bangalore");
			cities.add("Mumbai");
			cities.add("Delhi");
			cities.add("Kolkata");
			view.addObject("cities", cities);
		} else {
			
				boolean result2 = service.addHotels(hotel);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new HotelBean());
					view.addObject("successMessage","Added Hotel Successfully");
				}

			
		}
		return view;

	}

	@RequestMapping("DeleteHotel")
	public ModelAndView getDeleteHotelPage() {
		ModelAndView view = new ModelAndView("DeleteHotel", "hotel",
				new HotelBean());
		return view;

	}

	@RequestMapping("deleteHotelDetails")
	public ModelAndView deleteHotelDetails(@ModelAttribute("hotel") HotelBean hotel) {
		ModelAndView view = new ModelAndView();
			boolean result1=service.validateHotelId(hotel.getHotelId());
			if(result1)
			{
				
			boolean result = service.deleteHotel(hotel.getHotelId());
			if (result) {
				view = new ModelAndView("DisplayForAdmin", "hotel", new HotelBean());
				view.addObject("successMessage","Deleted Hotel Successfully");
			}
			}
			else
			{
				view=new ModelAndView("DeleteHotel","hotel",new HotelBean());
				String msg="No such hotel id exists";
				view.addObject("errorMessage",msg);
			}
		return view;

	}

	@RequestMapping("ModifyHotel")
	public ModelAndView getModifyHotelPage() {
		ModelAndView view = new ModelAndView("ModifyHotel", "hotel",
				new HotelBean());
		return view;

	}

	@RequestMapping("modifyHotelDetails")
	public ModelAndView modifyHotelDetails(
			@ModelAttribute("hotel") @Valid HotelBean hotel, BindingResult result) {
		System.out.println(hotel.getHotelId());
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("ModifyHotel", "hotel", hotel);
		} else {
			
				boolean result2 = service.modifyHotel(hotel);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new HotelBean());
					view.addObject("successMessage","Modified Hotel Successfully");
				}
				else
				{
					view.addObject("errorMessage", "No hotels found with given hotel ID");
					view.setViewName("ModifyHotel");
				}
			
		}

		return view;

	}

	@RequestMapping("getHotelDetailsById")
	public ModelAndView getHotelDetailsById(@ModelAttribute("hotel") HotelBean hotel) {

		ModelAndView view = new ModelAndView();
		ArrayList<HotelBean> list = service.getHotelList(hotel.getHotelId());
		if (!list.isEmpty()) {
			view = new ModelAndView("ModifyHotel", "hotel", new HotelBean());
			view.addObject("hotelDetails", list);
		}
		else
		{
			view.addObject("errorMessage", "No hotels found with given hotel ID");
			view.setViewName("ModifyHotel");
		}
		return view;

	}

	@RequestMapping("ViewHotelList")
	public ModelAndView getHotelList() {
		ModelAndView view = new ModelAndView();
		
			ArrayList<HotelBean> list = service.getHotelList();
			if (!list.isEmpty()) {
				view.addObject("hotelList", list);
				view.setViewName("ViewHotelList");
			} else {
				view.addObject("errorMessage", "No hotels to display");
				view.setViewName("ViewHotelList");
			}
		
		return view;

	}
	@RequestMapping("ViewHotelListForUser")
	public ModelAndView getHotelListForUser() {
		ModelAndView view = new ModelAndView();
		
			ArrayList<HotelBean> list = service.getHotelList();
			if (!list.isEmpty()) {
				view.addObject("hotelList", list);
				view.setViewName("ViewHotelListForUser");
			} else {
				view.addObject("errorMessage", "No hotels to display");
				view.setViewName("ViewHotelListForUser");
			}
		
		return view;

	}
	@RequestMapping("ViewBooking")
	public ModelAndView getBookingsPage() {
		ModelAndView view = new ModelAndView("ViewBooking", "hotel",
				new HotelBean());

		return view;

	}

	@RequestMapping("getBookingDetailsById")
	public ModelAndView getBookingDetailsById(
			@ModelAttribute("hotel") HotelBean hotel) {
		ModelAndView view = new ModelAndView();
		
			ArrayList<BookingDetailsBean> list = service.retrieveBookings(hotel
					.getHotelId());
			if (!list.isEmpty()) {
				view.addObject("bookingDetails", list);
				view.setViewName("ViewBooking");
			} else {
				view.addObject("errorMessage",
						"No Bookings found for given Hotel Id");
				view.setViewName("ViewBooking");
			}

		

		return view;

	}

	@RequestMapping("ViewGuestList")
	public ModelAndView getGuestListPage() {
		ModelAndView view = new ModelAndView("ViewGuestList", "hotel",
				new HotelBean());

		return view;

	}

	@RequestMapping("getGuestList")
	public ModelAndView getGuestListById(@ModelAttribute("hotel") HotelBean hotel) {
		ModelAndView view = new ModelAndView();
		
			BookingDetailsBean details = service.retrieveGuestList(hotel
					.getHotelId());
			System.out.println(details);
			ArrayList<BookingDetailsBean> list = null;

			if (null != details) {
				list = new ArrayList<BookingDetailsBean>();
				list.add(details);
				view.addObject("guestList", list);
				view.setViewName("ViewGuestList");
			} else {
				view.addObject("errorMessage",
						"No Guest List found for given Hotel Id");
				view.setViewName("ViewGuestList");
			}

		

		return view;

	}

	@RequestMapping("ViewSpecificBooking")
	public ModelAndView getBookingDetailsPage() {
		ModelAndView view = new ModelAndView("ViewSpecificBooking", "booking",
				new BookingDetailsBean());

		return view;

	}

	@RequestMapping("getBookingDetailsByDate")
	public ModelAndView getBookingDetailsByDate(
			@RequestParam("currentDate") String date) {
		ModelAndView view = new ModelAndView();
					DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			LocalDate currentDate = LocalDate.parse(date, formatter);

			ArrayList<BookingDetailsBean> list = service
					.retrieveBookings(currentDate);
			if (!list.isEmpty()) {
				view.addObject("bookingDetails", list);
				view.setViewName("ViewSpecificBooking");
			} else {
				view.addObject("errorMessage",
						"No Bookings found for given Date");
				view.setViewName("ViewSpecificBooking");
			}

		

		return view;

	}
	
	
/*
 * Room Details
 */
	@RequestMapping("AddRoom")
	public ModelAndView getAddRoomPage() {
		ModelAndView view = new ModelAndView("AddRoom", "room",
				new RoomDetailsBean());
		ArrayList<String> type = new ArrayList<String>();
		type.add("Standard non A/C room");
		type.add("Standard A/C room");
		type.add("Executive A/C room");
		type.add("Deluxe A/C room");
		view.addObject("type", type);
		return view;

	}

	@RequestMapping("addRoomDetails")
	public ModelAndView saveRoomDetails(
			@ModelAttribute("room") @Valid RoomDetailsBean roomDetails,
			BindingResult result) {

		ModelAndView view = new ModelAndView();

		if (result.hasErrors()) {
			view = new ModelAndView("AddRoom", "room", roomDetails);
			ArrayList<String> type = new ArrayList<String>();
			type.add("Standard non A/C room");
			type.add("Standard A/C room");
			type.add("Executive A/C room");
			type.add("Deluxe A/C room");
			view.addObject("type", type);
		} else {

			

				boolean result1 = service.validateHotelId(roomDetails
						.getHotelId());
				System.out.println("validated");
				if (result1) {
					boolean result2 = service.addRooms(roomDetails);
					//System.out.println("added successfull");
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new HotelBean());
					if (result2) {
						view.addObject("successMessage","Added Room Successfully");

					}

				}
				else
				{
					view = new ModelAndView("AddRoom", "room", roomDetails);
					ArrayList<String> type = new ArrayList<String>();
					type.add("Standard non A/C room");
					type.add("Standard A/C room");
					type.add("Executive A/C room");
					type.add(" Deluxe A/C room");
					view.addObject("type", type);
				
				}

			
		}
		return view;

	}

	@RequestMapping("DeleteRoom")
	public ModelAndView getDeleteRoomPage() {
		ModelAndView view = new ModelAndView("DeleteRoom", "room",
				new RoomDetailsBean());
		return view;

	}

	@RequestMapping("deleteRoomDetails")
	public ModelAndView deleteRoomDetails(
			@ModelAttribute("room") RoomDetailsBean roomDetails) {
		ModelAndView view = new ModelAndView();
		boolean result=service.checkRoomId(roomDetails.getRoomId());
		if(result)
		{
			boolean result1 = service.deleteRooms(roomDetails.getRoomId());
			if (result1) {
				view = new ModelAndView("DisplayForAdmin", "hotel", new HotelBean());
				view.addObject("successMessage","Deleted Room Successfully");
			}
		}
			else
			{
				view = new ModelAndView("DeleteRoom", "room", new RoomDetailsBean());
				String msg="No such room id exists";
				view.addObject("errorMessage",msg);
			}
		return view;

	}

	@RequestMapping("ModifyRoom")
	public ModelAndView getModifyRoomPage() {
		ModelAndView view = new ModelAndView("ModifyRoom", "room",
				new RoomDetailsBean());
		return view;

	}

	@RequestMapping("getDetailsById")
	public ModelAndView getDetailsById(
			@ModelAttribute("room") RoomDetailsBean roomDetails) {

		ModelAndView view = new ModelAndView();
		boolean result1=service.validateHotelId(roomDetails.getHotelId());
		if(result1)
		{
		boolean result=service.checkRoomId(roomDetails.getRoomId());
		if(result)
		{
		ArrayList<RoomDetailsBean> list = service.getRoomList(roomDetails);

		if (!list.isEmpty()) {
			view = new ModelAndView("ModifyRoom", "room", new RoomDetailsBean());
			view.addObject("roomDetails", list);
		}
		}
		else
		{
			view = new ModelAndView("ModifyRoom", "room", new RoomDetailsBean());
			String msg="No such room id exists";
			view.addObject("errorMessage",msg);
		}
		}
		else
		{
			view = new ModelAndView("ModifyRoom", "room", new RoomDetailsBean());
			String msg="No such Hotel id exists";
			view.addObject("errorMessage",msg);
		}
		return view;
	}

	@RequestMapping("modifyRoomDetails")
	public ModelAndView modifyRoomDetails(
			@ModelAttribute("room") @Valid RoomDetailsBean roomDetails,
			BindingResult result) {
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("ModifyRoom", "room", roomDetails);
			
		} else {
			
				boolean result2 = service.modifyRoom(roomDetails);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new HotelBean());
					view.addObject("successMessage","Modified Room Successfully");
				}
			
		}

		return view;
	}
	@RequestMapping("hotelManagement")
	public ModelAndView getHotelPage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("HotelManagement");
		return view;
	}
	
	@RequestMapping("roomManagement")
	public ModelAndView getRoomPage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("RoomManagement");
		return view;
	}

	@RequestMapping("viewReports")
	public ModelAndView getReports() {
		ModelAndView view = new ModelAndView();
		view.setViewName("ViewReports");
		return view;
	}
	

	
	@RequestMapping("roomBooking")
	public ModelAndView roomBooking() {
		ModelAndView view = new ModelAndView("BookARoom","room",new RoomDetailsBean());
		
		return view;
	}
	

	@RequestMapping("logout")
	public ModelAndView logout() {
		return new ModelAndView("logout");
		
	}

}