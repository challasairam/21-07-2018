package com.cg.miniproject.service;


import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetailsBean;
import com.cg.miniproject.bean.HotelBean;
import com.cg.miniproject.bean.RoomDetailsBean;
import com.cg.miniproject.bean.UserBean;

public interface IHotelBookingService {

	public UserBean login(UserBean user);

	public boolean register(UserBean user);

	public boolean addHotels(HotelBean hotel);

	public boolean deleteHotel(Integer id);

	public boolean addRooms(RoomDetailsBean roomDetails);

	public boolean deleteRooms(Integer id);

	public ArrayList<BookingDetailsBean> retrieveBookings(Integer hotelId);

	public ArrayList<BookingDetailsBean> retrieveBookings(LocalDate date);

	public ArrayList<HotelBean> getHotelList();

	public ArrayList<RoomDetailsBean> getRoomDetails(Integer id);

	public BookingDetailsBean insertBookingDetails(BookingDetailsBean bookingDetails);

	public boolean fetchUserName(String userName);


	public BookingDetailsBean retrieveGuestList(Integer hotelId);

	public boolean viewBookingStatus(Integer userId);

	public boolean modifyHotel(HotelBean hotel2);

	public boolean modifyRoom(RoomDetailsBean details);

	public boolean validateHotelId(Integer hotelId);

	public ArrayList<HotelBean> getHotelList(Integer hotelId);

	public ArrayList<RoomDetailsBean> getRoomList(RoomDetailsBean roomDetails);

	public boolean checkRoomId(Integer roomId);
}
