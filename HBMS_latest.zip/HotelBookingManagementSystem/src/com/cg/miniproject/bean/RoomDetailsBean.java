package com.cg.miniproject.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "roomdetails")
@NamedQueries({
		@NamedQuery(name = "getRoomDetails", query = "select details from RoomDetailsBean details where details.hotelId=:id and details.availability='A'"),
		@NamedQuery(name = "roomlist", query = "select details from RoomDetailsBean details where details.hotelId=:hid AND details.roomId=:rid"),
		@NamedQuery(name = "retrieveRooms", query = "select r from RoomDetailsBean r where r.roomId=:id") })
@SequenceGenerator(name = "room_id", sequenceName = "room_id_sequence", allocationSize = 1)
public class RoomDetailsBean {
	@Column(name = "hotel_id")
	private Integer hotelId;
	@Id
	@GeneratedValue(generator = "room_id")
	@Column(name = "room_id")
	private Integer roomId;
	@NotEmpty(message="*Please fill out this field")
	@Pattern(regexp="^[0-4]{3}$",message="Room no should contain only 3 numbers")
	@Column(name = "room_no")
	private String roomNo;
	@NotEmpty(message="*Please fill out this field")
	@Column(name = "room_type")
	private String roomType;
	@Column(name = "per_night_rate")
	private Double perNightRate;
	@Pattern(regexp="[A|NA]", message = "only A or NA")
	@Column(name = "availability")
	private String availability;

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public Integer getHotelId() {
		return hotelId;
	}

	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}

	public Integer getRoomId() {
		return roomId;
	}

	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public Double getPerNightRate() {
		return perNightRate;
	}

	public void setPerNightRate(Double perNightRate) {
		this.perNightRate = perNightRate;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public RoomDetailsBean() {

	}

	@Override
	public String toString() {
		return "RoomDetails [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability + "]";
	}

}