package com.cg.miniproject.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.miniproject.bean.BookingDetailsBean;
import com.cg.miniproject.bean.HotelBean;
import com.cg.miniproject.bean.RoomDetailsBean;
import com.cg.miniproject.bean.UserBean;

@Repository
@Transactional
public class HotelBookingDaoImpl implements IHotelBookingDao {
	boolean b, result = false;

	@PersistenceContext
	EntityManager entityManager;

	/*
	 * To register a new user/employee
	 */
	@Override
	public boolean register(UserBean user)  {

		entityManager.persist(user);
		entityManager.flush();
		b = true;
		return b;
	}

	/*
	 * To login a user/employee
	 */
	public UserBean login(UserBean user)  {

		UserBean user2 = null;
		Query query = entityManager.createNamedQuery("login");
		query.setParameter("uname", user.getUserName());
		query.setParameter("pwd", user.getPassword());
		query.setParameter("role", user.getRole());
		@SuppressWarnings("unchecked")
		ArrayList<UserBean> list = (ArrayList<UserBean>) query.getResultList();
		System.out.println();
		if (!list.isEmpty()) {
			user.setUserId(list.get(0).getUserId());
			user2 = user;
		}

		return user2;
	}

	/*
	 * To add Hotels in the hotel table
	 */
	@Override
	public boolean addHotels(HotelBean hotel)  {

		entityManager.persist(hotel);
		entityManager.flush();
		result = true;
		return result;
	}

	/*
	 * To delete hotel based on hotel Id
	 */
	@Override
	public boolean deleteHotel(Integer id) {

		HotelBean hotel = entityManager.find(HotelBean.class, id);
		entityManager.remove(hotel);
		result = true;
		return result;
	}

	/*
	 * To add new rooms for a particular hotel
	 */
	@Override
	public boolean addRooms(RoomDetailsBean roomDetails) {
		
		entityManager.persist(roomDetails);
		entityManager.flush();
		result=true;
		return result;
	}

	/*
	 * To delete rooms for a particular hotel based on room id
	 */
	@Override
	public boolean deleteRooms(Integer id)  {
		RoomDetailsBean roomDetails=entityManager.find(RoomDetailsBean.class,id);
		entityManager.remove(roomDetails);
		result=true;
		return result;
	}

	/*
	 * To retrieve bookings for a particular hotel based on hotel Id
	 */
	@Override
	public ArrayList<BookingDetailsBean> retrieveBookings(Integer hotelId)
			 {
		Query query = entityManager
				.createQuery("SELECT b FROM BookingDetailsBean b,RoomDetailsBean r,HotelBean h WHERE h.hotelId=r.hotelId and b.roomId=r.roomId and h.hotelId=:id");
		query.setParameter("id", hotelId);
		@SuppressWarnings("unchecked")
		ArrayList<BookingDetailsBean> list = (ArrayList<BookingDetailsBean>) query
				.getResultList();
		return list;

	}

	/*
	 * To retrieve bookings for a particular hotel based on Date
	 */
	@Override
	public ArrayList<BookingDetailsBean> retrieveBookings(LocalDate date)
			 {

		Date currentDate=Date.valueOf(date);
		Query query=entityManager.createQuery("SELECT b FROM BookingDetailsBean b WHERE :cdate BETWEEN b.bookedFrom AND b.bookedTo");
		query.setParameter("cdate",currentDate);
		@SuppressWarnings("unchecked")
		ArrayList<BookingDetailsBean> list = (ArrayList<BookingDetailsBean>) query
				.getResultList();
		return list;

	}

	/*
	 * To retrieve list of hotels
	 */
	@Override
	public ArrayList<HotelBean> getHotelList(){

		Query query = entityManager.createNamedQuery("listAllHotels");
		@SuppressWarnings("unchecked")
		ArrayList<HotelBean> list = (ArrayList<HotelBean>) query.getResultList();
		return list;
	}

	/*
	 * To retrieve room details based on hotel Id
	 */
	@Override
	public ArrayList<RoomDetailsBean> getRoomDetails(Integer id)
			 {

		Query query = entityManager.createNamedQuery("getRoomDetails");
		query.setParameter("id",id);
		@SuppressWarnings("unchecked")
		ArrayList<RoomDetailsBean> list = (ArrayList<RoomDetailsBean>) query
				.getResultList();
		return list;
	}

	/*
	 * To insert booking details into database
	 */
	@Override
	public BookingDetailsBean insertBookingDetails(BookingDetailsBean bookingDetails)
			 {
		DateTimeFormatter dateFormat = DateTimeFormatter
				.ofPattern("yyyy-MM-dd");
		LocalDate stDate = LocalDate.parse(bookingDetails.getBookedFromDate(),
				dateFormat);
		LocalDate endDate = LocalDate.parse(bookingDetails.getBookedToDate(),
				dateFormat);
		Period period = Period.between(stDate, endDate);
		Double diff = (double) period.getDays();
		//System.out.println(bookingDetails.getRoomId());
		RoomDetailsBean details = entityManager.find(RoomDetailsBean.class,
				bookingDetails.getRoomId());
		Double amount = details.getPerNightRate() * diff;
		bookingDetails.setAmount(amount);
		bookingDetails.setBookedFrom(Date.valueOf(stDate));
		bookingDetails.setBookedTo(Date.valueOf(endDate));
		System.out.println(bookingDetails);
		entityManager.persist(bookingDetails);
		RoomDetailsBean roomDetails=entityManager.find(RoomDetailsBean.class, bookingDetails.getRoomId());
		roomDetails.setAvailability("NA");
		entityManager.merge(roomDetails);
		entityManager.flush();
		return bookingDetails;
	}

	/*
	 * To retrieve user Id
	 */
	@Override
	public boolean fetchUserName(String userName)  {

		boolean result=false;
		Query query=entityManager.createNamedQuery("fetchUserName");
		query.setParameter("uname", userName);
		@SuppressWarnings("unchecked")
		ArrayList<UserBean> list=(ArrayList<UserBean>) query.getResultList();
		if(!list.isEmpty())
			result=true;
		return result;
	}

	/*
	 * To retrieve bookings for a particular hotel based on hotel Id
	 */
	@Override
	public BookingDetailsBean retrieveGuestList(Integer hotelId)
			 {
		Query query=entityManager.createQuery("SELECT sum(b.noOfAdults) FROM BookingDetailsBean b,RoomDetailsBean r,HotelBean h WHERE h.hotelId=r.hotelId and b.roomId=r.roomId and h.hotelId=:id");
		query.setParameter("id",hotelId);
		Long result = (Long) query.getSingleResult();
	      Query query1=entityManager.createQuery("SELECT sum(b.noOfChildren) FROM BookingDetailsBean b,RoomDetailsBean r,HotelBean h WHERE h.hotelId=r.hotelId and b.roomId=r.roomId and h.hotelId=:id");
	      query1.setParameter("id",hotelId);
	      Long result1 = (Long) query1.getSingleResult();
	      System.out.println(result+" "+result1);
		BookingDetailsBean details=new BookingDetailsBean();
		if(null!=result && null !=result1)
		{
		details.setNoOfAdults(result.intValue());
		details.setNoOfChildren(result1.intValue());
		}
		else
		{
			details=null;
		}
		return details;
	}

	

	/*
	 * To retrieve booking status based on booking details
	 */
	public boolean viewBookingStatus(Integer id) {
		boolean res= false;
		System.out.println("Id"+id);
		Query query = entityManager.createNamedQuery("bookingstatus");
		query.setParameter("uid", id);
		ArrayList<BookingDetailsBean> list= (ArrayList<BookingDetailsBean>) query.getResultList();
		System.out.println(list);
		if (!list.isEmpty())
			res = true;
		return res;
	}

	/*
	 * To modify hotel details
	 */
	@Override
	public boolean modifyHotel(HotelBean hotel) {
		System.out.println(hotel.getHotelId());
		entityManager.merge(hotel);
		entityManager.flush();
		result = true;
		return result;
	}

	/*
	 * To modify room details
	 */
public boolean modifyRoom(RoomDetailsBean details)  {
		
		entityManager.merge(details);
		entityManager.flush();
		result=true;
		return result;
	}

	/*
	 * To validate hotel Id
	 */
	public boolean validateHotelId(Integer hotelId) {
		boolean result=false;
		Query query=entityManager.createNamedQuery("retrieveHotels");
		query.setParameter("id",hotelId);
		ArrayList<HotelBean> list = (ArrayList<HotelBean>) query.getResultList();
		if(!list.isEmpty())
			result=true;
		return result;
	}

	@Override
	public ArrayList<HotelBean> getHotelList(Integer hotelId) {
		Query query = entityManager.createNamedQuery("retrieveHotels");
		query.setParameter("id", hotelId);
		ArrayList<HotelBean> list = (ArrayList<HotelBean>) query.getResultList();
		return list;
	}
	
	@Override
	public ArrayList<RoomDetailsBean> getRoomList(RoomDetailsBean roomDetails) {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("roomlist");
		query.setParameter("hid",roomDetails.getHotelId());
		query.setParameter("rid",roomDetails.getRoomId());
		ArrayList<RoomDetailsBean> list=(ArrayList<RoomDetailsBean>) query.getResultList();
		System.out.println(list);
		return list;
	}

	@Override
	public boolean checkRoomId(Integer roomId) {
		boolean result=false;
		Query query=entityManager.createNamedQuery("retrieveRooms");
		query.setParameter("id",roomId);
		ArrayList<HotelBean> list = (ArrayList<HotelBean>) query.getResultList();
		if(!list.isEmpty())
			result=true;
		return result;
	}



}
