package com.cg.miniproject.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name="users")
@NamedQueries({@NamedQuery(name="login",query="select user from UserBean user where user.userName=:uname and user.password=:pwd and user.role=:role"),@NamedQuery(name="fetchUserName",query="select user from UserBean user where user.userName=:uname")})
@SequenceGenerator(name="user_id",sequenceName="user_id_sequence",allocationSize=1)
public class UserBean {
	@Id
	@GeneratedValue(generator="user_id")
	@Column(name="user_id")
	private Integer userId;
	@NotEmpty(message="*Password should not be empty")
	@Pattern(regexp="^[A-Za-z0-9]{4,7}$",message="Please check your password")
	@Column(name="password")
	private String password;
	@Column(name="role")
	private String role;
	@Pattern(regexp="[A-Za-z ]{4,10}", message = "Name must be in characters only in range of 4 to 10")
	@NotEmpty(message="*Field Cannot be empty")
	@Column(name="user_name")
	private String userName;
	@Column(name="mobile_no")
	@NotEmpty(message="*Field Cannot be empty")
	@Pattern(regexp="^[0-9]{10}$",message="Should be of 10 digits only")
	private String mobileNo;
	@Column(name="phone")
	@NotEmpty(message="*Field Cannot be empty")
	@Pattern(regexp="^[0-9]{10}$",message="Should be of 10 digits only")
	private String phone;
	@Column(name="address")
	@NotEmpty(message="*Field Cannot be empty")
	private String address;
	@Column(name="email")
	@NotEmpty(message="*Field Cannot be empty")
	@Pattern(regexp="^[A-Za-z0-9]+[@]+[a-z]+[.]+[a-z]{1,4}",message="Not a Valid email")
	private String email;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public UserBean() {

	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", password=" + password + ", role="
				+ role + ", userName=" + userName + ", mobileNo=" + mobileNo
				+ ", phone=" + phone + ", address=" + address + ", email="
				+ email + "]";
	}

}
