package com.cg.miniproject.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="hotel")
@NamedQueries({@NamedQuery(name="listAllHotels",query="select h from HotelBean h"),@NamedQuery(name="retrieveHotels",query="select h from HotelBean h where h.hotelId=:id")})
@SequenceGenerator(name="hotel_id",sequenceName="hotel_id_sequence",allocationSize=1)
public class HotelBean {
	@Id
	@GeneratedValue(generator="hotel_id")
	@Column(name="hotel_id")
	private Integer hotelId;
	@Column(name="city")
	@NotEmpty(message="Please enter city name")
	private String city;
	@NotEmpty(message="Please enter hotel name")
	@Pattern(regexp="[A-Za-z ]{5,20}", message = "Must be in characters only in range of 5 to 20")
	@Column(name="hotel_name")
	private String hotelName;
	@NotEmpty(message="Please enter address")
	@Column(name="address")
	private String address;
	@NotEmpty(message="Give a brief description about hotel")
	@Pattern(regexp="[A-Za-z ]{4,30}", message = "Description only characters are allowed min:4 max:30")
	@Column(name="description")
	private String description;
	@Column(name="avg_rate_per_night")
	private Double avgRatePerNight;
	@NotEmpty(message="*Field can't be Empty")
	@Pattern(regexp="^[0-9]{10}$",message="Phone no Should be of 10 digits only")
	@Column(name="phone_no1")
	private String phoneNo1;
	@NotEmpty(message="*Field can't be Empty")
	@Pattern(regexp="^[0-9]{10}$",message="Phone no Should be of 10 digits only")
	@Column(name="phone_no2")
	private String phoneNo2;
	@Column(name="rating")
	private Double rating;
	@NotEmpty(message="*Field can't be Empty")
	@Pattern(regexp="^[A-Za-z0-9]+[@]+[a-z]+[.]+[a-z]{1,4}",message="Enter Valid email-Eg:abcd@gmail.com")
	@Column(name="email")
	private String email;
	@NotEmpty(message="*Field can't be Empty")
	@Pattern(regexp="^[0-9]{10}$",message="Should be of 10 digits only")
	@Column(name="fax")
	private String fax;

	public Integer getHotelId() {
		return hotelId;
	}

	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getAvgRatePerNight() {
		return avgRatePerNight;
	}

	public void setAvgRatePerNight(Double avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}

	public String getPhoneNo1() {
		return phoneNo1;
	}

	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}

	public String getPhoneNo2() {
		return phoneNo2;
	}

	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public HotelBean() {

	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", city=" + city + ", hotelName="
				+ hotelName + ", address=" + address + ", description="
				+ description + ", avgRatePerNight=" + avgRatePerNight
				+ ", phoneNo1=" + phoneNo1 + ", phoneNo2=" + phoneNo2
				+ ", rating=" + rating + ", email=" + email + ", fax=" + fax
				+ "]";
	}

}